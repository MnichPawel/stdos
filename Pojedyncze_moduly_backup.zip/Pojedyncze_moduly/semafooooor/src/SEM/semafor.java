package SEM;
import java.util.ArrayDeque;

public class semafor {

   public int wartosc=1;
   public ArrayDeque<PBC> kolejka= new ArrayDeque<>();
   public semafor(int war){
        wartosc = war;
    }


}

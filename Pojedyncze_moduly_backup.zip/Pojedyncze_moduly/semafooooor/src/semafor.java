package CPU;
import java.util.ArrayDeque;

public class semafor {

    int wartosc=1;
    ArrayDeque<PBC> kolejka= new ArrayDeque<>();
    semafor(int war){
        wartosc = war;
    }


}

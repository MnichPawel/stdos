package VirtualMemory;

public class SegmentClass {
    public int pId;
    public Boolean pInVM;
    public Boolean pVictim;

    public SegmentClass() {
        pId = -1;
        pInVM = false;
        pVictim = false;
    }
}

package VirtualMemory;

public class RAMContainer {
    int pId = -1;
    int indexInRam = -1;
}

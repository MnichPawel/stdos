package ProcessManager;

public enum ProcessState {
    NEW, READY, WAITING, RUNNING;
}

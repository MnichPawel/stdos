package Interpreter;

public class Main {
    public static void main(String[] args) {
        //PCB pcb = MM_getRUNNING();
        //int address = pcb.getPC();
        int pobrany = 65;
        //pobrany = get_value(address);
        char do_sprawdzenia = (char)pobrany;
        System.out.println(do_sprawdzenia);
    }
}

package VirtualMemory;

public class Segment {
    int beginAddress;
    int limit;

    Segment() {
        beginAddress = -1;
        limit = 0;
    }
}
